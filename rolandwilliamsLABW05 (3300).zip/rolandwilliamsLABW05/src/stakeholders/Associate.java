package stakeholders;

import security.Credential;
//creates Associates using the Profile and Credential classes, uses position name to separate them from customers
public class Associate implements Comparable<Associate>, Cloneable{

	private Profile profile;
	private Credential credential;	
	private String title;

	public Associate(Profile profile, Credential credential,String title) {
		this.profile = profile;
		this.credential = credential;						//Associate constructor with profile, credential. and title class members
		this.setTitle(title);
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Profile getProfile() {							//Mutator for title
		return profile;										//Accessor for all class members						
	}
	public Credential getCredential() {
		return credential;
	}
	public String getTitle() {
		return title;
	}
	
	@Override
	public String toString() {
		return String.format("\n%s %s %-25s", profile, credential, title);
	}	
	@Override
	public boolean equals(Object obj) {
		if(obj == null || !(obj instanceof Associate)) {
			return false;
		}
		else if(this == obj) {
			return true;
		}
		Associate associate = (Associate) obj;
		if(associate.profile.equals((Profile)obj)
				&&associate.credential.equals((Credential)obj)) {
			return true;
		}
		return false;
	}
	@Override
	public int compareTo(Associate obj) {
		if(obj != null) {
			if(obj != null) {
				String thisLastname = this.profile.getLastname();
				String objLastname = obj.profile.getLastname();
				if(this == obj || thisLastname.equals(objLastname)) {
					return 0;
			}
				else if(thisLastname.compareTo(objLastname) > 0) {
					return 1;
			}
				else {
					return -1;
	}
	}
	}
	return -1;
}
	@Override
	public Associate clone() throws CloneNotSupportedException {
		Associate clone = (Associate) super.clone();
		if(clone != null) {
			clone = new Associate(this.getProfile(), this.getCredential(), this.getTitle());
	}
		return clone;
	}
}
