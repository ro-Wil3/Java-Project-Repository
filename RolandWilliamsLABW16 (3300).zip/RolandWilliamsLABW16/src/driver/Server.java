package driver;

import account.Account;
import server.Balance;
import server.Bank;

public class Server {
	
	public static void main(String []args) {
		Account account = new Account();
		Balance bc = new Balance(account);
		Bank bank = new Bank(9999, account);
		bc.start();
		bank.start();
	}
}
