package facilities;

public class Office {
	protected String officeNumber;
	protected String officePhone;
	
	public Office(String officeNumber, String officePhone) {
		this.officeNumber = officeNumber;
		this.officePhone = officePhone;
	}
	public void setOfficeNumber(String officeNumber) {
		this.officeNumber = officeNumber;
	}
	public void setOfficePhone(String officePhone) {
		this.officePhone = officePhone;
	}
	public String getOfficeNumber() {
		return officeNumber;
	}
	public String getOfficePhone() {
		return officePhone;
	}
	@Override
	public String toString() {
		return String.format("(%s,%s)",officeNumber,officePhone);
	}
}
