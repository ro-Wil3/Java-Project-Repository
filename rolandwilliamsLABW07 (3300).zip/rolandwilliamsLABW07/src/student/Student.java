package student;
import people.Discrim;
import people.Person;
public class Student extends Person implements Discrim{

	private String studentType;
	protected String studentMajor;
	protected int CWID;
	
	public Student(String personID,String lastname,String firstname, boolean isEmployee, boolean isStudent, String studentType,String studentMajor, int CWID) {
		super(personID,lastname,firstname, false,true);
		setStudentType(studentType);
		this.studentMajor = studentMajor;
		this.CWID = CWID;
	}
	public boolean setStudentType(String studentType) {
		if(studentType.equals(STU_GRAD)||studentType.equals(STU_UNDERGRAD)) {
			this.studentType = studentType;
			return true;
		}
		else {
			this.studentType = STU_ERROR;
			return false;
		}
	}
	public void setStudentMajor(String studentMajor) {
		this.studentMajor = studentMajor;
	}
	public void setCWID(int CWID) {
		this.CWID = CWID;
	}
	public String getStudentType() {
		return studentType;
	}
	public String getStudentMajor() {
		return studentMajor;
	}
	public int getCWID() {
		return CWID;
	}
	@Override
	public String toString() {
		return super.toString() + String.format(",%s,%s",studentType,studentMajor);
	}
}
