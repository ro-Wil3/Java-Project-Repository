package people;

public interface Discrim {
String STU_GRAD = "G";
String STU_UNDERGRAD = "U";
String STU_ERROR = "E";


String EMP_Y = "Y";
String EMP_N ="N";
String EMP_ERROR = "E";

String STF_IT = "IT";
String STF_ERROR = "E";

String IT_STAFF_AS = "AS";
String IT_STAFF_TS = "TS";
String IT_STAFF_ERROR = "E";

String T_PASS = "YES";
String T_FAIL = "NO";
String T_ERROR = "ERROR";
}
