/*******************************************************************************
* Name: Roland Williams
* Course: CIS 3970 Programming Principles
* Semester: Spring 2024
* Assignment: Lab W16
* Date started: 4/22/24
* Date finished: 4/27/24
* Description: Setting up a server and a client to exchange information in tracking the balance after multiple transactions(threads) are hitting the account
*******************************************************************************/
package account;

public class Account {
	
	private int balance;
	
	public Account() {
		balance = 0;
	}
	
	public void adjust(int amount) {
		balance += amount;
	}
	
	public int getBalance() {
		return balance; 
	}

}
