package training;

import people.Discrim;

public class Training implements Discrim{
	protected int trainingID;
	protected String trainingCategory;
	protected String dateTaken;
	protected String takenType;
	protected String passTraining;
	
	
	public Training(int trainingID, String trainingCategory, String dateTaken, String takenType, String passTraining) {
		this.trainingID = trainingID;
		this.trainingCategory = trainingCategory;
		this.dateTaken = dateTaken;
		this.takenType = takenType;
		setPassTraining(passTraining);
	}
	public void setTrainingID(int trainingID) {
		this.trainingID = trainingID;
	}
	public void setTrainingCategory(String trainingCategory) {
		this.trainingCategory = trainingCategory;
	}
	public void setDateTaken(String dateTaken) {
		this.dateTaken = dateTaken;
	}
	public void setTakenType(String takenType) {
		this.takenType = takenType;
	}
	public void setPassTraining(String passTraining) {
		if(passTraining.equals(T_PASS)|| passTraining.equals(T_FAIL)) {
			this.passTraining = passTraining;
		}
		else {
			this.passTraining = T_ERROR;
		}
	}
	public int getTrainingID() {
		return trainingID;
	}
	public String getTrainingCategory() {
		return trainingCategory;
	}
	public String getDateTaken() {
		return dateTaken;
	}
	public String getTakenType() {
		return takenType;
	}
	public String getPassTraining() {
		return passTraining;
	}
	@Override
	public String toString() {
		return String.format("%d,%s,%s,%s,%s", trainingID,trainingCategory,dateTaken,takenType,passTraining);
	}
}
