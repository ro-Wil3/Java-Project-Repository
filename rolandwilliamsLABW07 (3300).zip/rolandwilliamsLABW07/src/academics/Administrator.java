package academics;

import employee.Employee;
import facilities.Office;

public class Administrator extends Employee{

	protected String adminTitle;
	protected char adminPosition;
	
	public Administrator(String personID,String lastname,String firstname, boolean isEmployee,boolean isStudent, String hireDate, String isAdmin, String isProf, Office office,String adminTitle) {
		
		super(personID,lastname,firstname, isEmployee,isStudent,hireDate,isAdmin,isProf,office);
		this.adminTitle = adminTitle;
	}
	public Administrator(String employeeID,String lastname,String firstname, boolean isEmployee, boolean isStudent, String hireDate, String isAdmin, String isProf, Office office,char adminPosition) {
		super(employeeID,lastname,firstname, true,false,hireDate,"Y","N",office);
		this.adminPosition = adminPosition;
	}
	public void setAdminTitle(String adminTitle) {
		this.adminTitle = adminTitle;
	}
	public void setAdminPosition(char adminPosition) {
		this.adminPosition = adminPosition;
	}
	public String getAdminTitle() {
		return adminTitle;
	}
	public char getAdminPosition() {
		return adminPosition;
	}
	@Override
	public String toString(){
		if(adminTitle != null) {
		return super.toString() + String.format(",%s",adminTitle);
		}
		else {
			return super.toString() + String.format(",%c",adminPosition);
		}
	}
}
