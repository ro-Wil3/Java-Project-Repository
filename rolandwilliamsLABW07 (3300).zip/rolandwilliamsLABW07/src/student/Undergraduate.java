package student;

public class Undergraduate extends Student{

	protected int undergradHours;
	
	public Undergraduate(String personID,String lastname,String firstname, boolean isEmployee, boolean isStudent, String studentType,String studentMajor, int CWID,int undergradHours) {
		super(personID,lastname,firstname, false,true,studentType,studentMajor,CWID);
		this.undergradHours = undergradHours;
	}
	public void setUndergradHours(int undergradHours) {
		this.undergradHours = undergradHours;
	}
	public int getUndergradHours() {
		return undergradHours;
	}
	@Override
	public String toString() {
		return super.toString() + String.format(",%d", undergradHours);
	}
}
