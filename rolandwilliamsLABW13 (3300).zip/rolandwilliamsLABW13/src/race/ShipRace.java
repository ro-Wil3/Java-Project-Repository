package race;

import java.util.Scanner;

import racing.Ship;
import racing.ShipRacing;

public class ShipRace {

	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);
		System.out.print("Length: "); 
		double length = scnr.nextDouble();
		System.out.print("Ships: ");
		int numOfShips = scnr.nextInt();
		System.out.print("Races: ");
		int numOfRaces =  scnr.nextInt();
		scnr.close();
		ShipRacing SR = new ShipRacing(length, numOfShips, numOfRaces);
		SR.start();
	}

}
