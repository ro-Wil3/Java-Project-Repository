package racing;

import racing.Track.Flag;

public class Ship extends Thread {
	
	protected long startTime;
	protected long elapseTime;
	protected int ID;
	protected double distance;

	public Ship(int ID) {
		this.ID = ID;
		this.distance = Track.length;
	} 
	
	@Override
	public void run() {
		while(Track.flag == Flag.IDLE) {
			try {
				Thread.sleep(0, 1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		startTime = System.currentTimeMillis();
		while(distance > 0) {
			this.distance -= 1.0;
		}
		elapseTime = System.currentTimeMillis() - startTime;
		//System.out.printf("id=%2d time=%3d\n", this.ID, this.elapseTime);
		//System.out.println(this);
		Track.winners.add(this);
	}
	@Override
	public String toString() {
		return String.format("(%d,%d)",ID,elapseTime);
	}
	
}
