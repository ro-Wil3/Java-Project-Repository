package server;

import account.Account;

public class Balance extends Thread{
	
	private Account account;
	
	public Balance(Account account) {
		this.account = account;
	}
	
	@Override
	public void run() {
		while(true) {
			System.out.println("Balance: " + account.getBalance());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}

