package driver;

import java.util.ArrayList;

import academics.Administrator;
import academics.Professor;
import employee.Employee;
import employee.Staff;
import facilities.Office;
import staff.AcademicSupport;
import staff.IT;
import staff.TechnicalSupport;
import student.Graduate;
import student.Student;
import student.Undergraduate;
import training.Training;

public class Driver {

	public static void main(String[] args) {
		Training training = new Training(2358973,"Safety","February 19, 2024","On-site","YES");
		ArrayList<Training> taken = new ArrayList<Training>();
		taken.add(training);
		Office office = new Office("Office 500A","318-308-6676");	
		Administrator admin = new Administrator("199859544", "Penrod", "Curtis",true,false,"February 20, 2024","Y","N",office,"Head Administrator");
		Professor prof = new Professor("635-52-100","Powell", "Jason",true,false,"July 12, 2009","N","Y",office, "Top 3");
		Employee employee = new Employee("192-55-493", "Payne","Cameron",true,false,"January 31, 2017","N","N",office);
		Staff staff = new Staff("077281904","Chan","Jackie","J.", "September 29, 1989","Y","N","N",5,"IT");
		AcademicSupport acad = new AcademicSupport("172345581","Padilla","Juan","L."," October 13, 2022","Y","N","N",2,"IT","AS",taken);
		IT it = new IT("200265482", "Williams","Roland","L.", "July 23,2021","Y","N","N",3,"IT","AS",taken);
		TechnicalSupport ts = new TechnicalSupport("243578690","Green","Draymond","L."," December 8, 2018","Y","N","N",7,"IT","TS",taken);
		Graduate grad = new Graduate("359-45-9910","Latrice","Patricia",false,true,"U","Political Science",200489342,"Cyber Security Investigations");
		Undergraduate underGrad = new Undergraduate("328-39-1768","Penrod","Curtis",false,true,"G","Computer Science",200193835,87);
		Student student = new Student("673-22-0109","Boyce","Dove",false,true,"U","Health and Exercise Science",199839387);
		
		//Any class with a second Constructor (Second diagram)
		Employee emp = new Employee("451378695","Taylor", "Green","L.","June 12, 2014","Y","N","N");
		Administrator adm = new Administrator("980432025","Sasquatch","Verb",true,false,"March 1, 2019","Y","N",office,'M');
		Professor pro = new Professor("172849431","Luther","Lex",true, false,"October 20, 2020","N","Y", office,"Engineering");
		
		System.out.println("Office:                 " + office);
		System.out.println("Administrator:          " + admin);
		System.out.println("Professor:              " + prof);
		System.out.println("Employee:               " + employee);
		System.out.println("Staff:                  " + staff);
		System.out.println("Academic Support:       " + acad);
		System.out.println("IT Staff:               " + it);
		System.out.println("Technical Support:      " + ts);
		System.out.println("Graduate Student:       " + grad);
		System.out.println("Undergraduate Student:  " + underGrad);
		System.out.println("Student:                " + student);
		System.out.println("Training:               " + training);
		System.out.println();
		System.out.println("Employee:               " + emp);
		System.out.println("Administrator:          " + adm);
		System.out.println("Professor:              " + pro);
		
	}

}
