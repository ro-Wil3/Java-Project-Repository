/*******************************************************************************
* Name:			Roland Williams
* Course:		CIS 4020.01I
* Semester:		Fall 2024
* Assignment:	Lab 2A
* File:			Queens.java
* Date started:	 8/26/24
* Date finished: 8/30/24
* Description:	This class sets up the parameter for the chess board and uses compiled methods with a column based approach
*  that sets the queen in a spot, removes them from a spot, and check to see if they are being attacked.
*  We then back track with conflicts until the we iterate through the entire board
*******************************************************************************/
package queens;

import java.util.Arrays;

public class Queens {

	private final int SIZE;		//height and width of the board
	private int[][] board;		//2d array used to store "empty spaces " & "Queens"
	
	//Description: Constructor to initiate the size of the board
	public Queens(int size) {
		this.SIZE = size;
		this.board = new int[this.SIZE][this.SIZE];
	}
	//Description:  Displays the chess board
	//PreConditions: None
	//PostConditions: Uses a for loop to iterate through the entire array and display chess board
	public void display() {
		for(int i = 0; i < board.length; i++) {
			System.out.println(Arrays.toString(this.board[i]));
		}
	}
	//Description:  Places Queens on a chess board insuring that they aren't attacking each other
	//PreCondition: Ensure the column is within the bounds of the board to make sure the column-based approach is correct
	//PostCondition: All queens are placed on the chess board to where they can not attack each other
	public boolean placeQueens(int col) {
		if(col >= SIZE) {
			return true;		//base case
		}
		else {
			boolean queenPlaced = false;
			int row = 0;
			while(!queenPlaced && (row < SIZE)) {
				if(attackCheck(row, col)) {
					++row;
				}
				else {
					set(row,col);
					queenPlaced = placeQueens(col+1);
					if(!queenPlaced) {	//backtrack
						remove(row,col);
						++row;
					}
				}
			}
			return queenPlaced;
		}
	}
	//Description: Places Queen on Chess Board
	//PreCondition:  Row and column must be correct bounds on the board
	//PostConditions: The queen is placed on "row" & "column" of the board
	private void set(int row, int col) {
		board[row][col] = 1;
	}
	//Description: Removes Queen from Chess Board
	//PreCondition:  Row and column must be correct bounds on the board
	//PostConditions: The queen is removed from "row" & "column" of the board
	private void remove(int row, int col) {
		board[row][col] = 0;
	}
	//Description: Checks Vertical, up, and down horizontals on the left side to see if a queen is placed in its path
	//Precondition: Row and column must be in correct bounds on the board
	//PostConditions: Returns true if there is a queen (1) in a vertical, horizontal, or diagonal position of the parameter otherwise false if there is none (0)
	private boolean attackCheck(int row, int col) {
		
		//Checks for a queen in the horizontal attacks on the same row
		for (int i = 0; i < col; i++) {
            if (board[row][i] == 1) {
                return true;
            }
        }
		//Checks for a queen in the downward diagonal attacks
        for (int i = row, j = col; i >= 0 && j >= 0; i--, j--) {
            if (board[i][j] == 1) {
                return true;
            }
        }
		//Checks for a queen in the upward diagonal attacks
        for (int i = row, j = col; i < SIZE && j >= 0; i++, j--) {
            if (board[i][j] == 1) {
                return true;
            } 
        }
		return false;
	}	
	
}
