package staff;
import java.util.ArrayList;

import training.Training;
public class TechnicalSupport extends IT{

	public TechnicalSupport(String employeeID, String lastname,String firstname, String initial, String hireDate, String staff, String isAdmin, String isProf,int staffLevel, String staffType,String itStaffGroup,ArrayList<Training> taken) {
		super(employeeID, lastname, firstname,initial, hireDate,"Y","N","N",staffLevel,"IT","TS", taken);
	}
	@Override
	public String toString() {
		return super.toString();
	}
}
