package server;

import java.io.IOException;

import java.net.ServerSocket;
import java.net.Socket;
import account.Account;

public class Bank extends Thread{
	
	private ServerSocket server;
	private Account account;
	
	public Bank(int port, Account account) {
		try {
			this.account = account;
			this.server = new ServerSocket(port);
			
		} catch (IOException e) {
			System.out.println(e);
		}
	}
	@Override
	public void run() {
		try {
			while(true) {
				Socket client = server.accept();
				CustomerHandler ch = new CustomerHandler(client,account);
				ch.start();
			}
		} catch(IOException e) {
			e.printStackTrace();
		}	
	}
	

}
