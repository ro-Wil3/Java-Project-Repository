package racing;

import java.util.ArrayList;

import racing.Track.Flag;

public class ShipRacing extends Thread{
	protected Track track;
	//protected Ship[] ships;
	protected ArrayList<Ship> ships;
	protected int races;
	
	public ShipRacing(double length, int numOfShips, int numOfRaces) {
		track = new Track(length);
		ships = new ArrayList<>(numOfShips);
		//ships = new Ship[numOfShips];
		races = numOfRaces;
	}
	@Override
	public void run() {

		for(int race = 0; race < races; race++) {
			track.reset();
			ships.clear();
			
			for(int ship = 0; ship < 10; ship++) {
				Ship newShip = new Ship(ship);
				ships.add(newShip);
				newShip.start();
				
			}
			
			countdown();
			
			for(int ship = 0; ship < 10; ship++) {
				try {
					Ship newShip = ships.get(ship);
					newShip.join();
					System.out.println(Track.winners);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}			
			
		}

		
		/*for(int race = 0; race < races; race++) {
			track.reset();
			for(int ship = 0; ship < ships.length; ship++) {
				ships[ship] = new Ship(ship);
				ships[ship].start();
			}
			countdown();
			for(int ship = 0; ship < ships.length; ship++) {
				try {
					ships[ship].join();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}			
			
		}*/
	}
	
	public static void countdown() {
		try {
			System.out.print("3...");
			Thread.sleep(1000);
			System.out.print("2...");
			Thread.sleep(1000);
			System.out.print("1...");
			Thread.sleep(1000);
			Track.flag = Flag.GO;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
