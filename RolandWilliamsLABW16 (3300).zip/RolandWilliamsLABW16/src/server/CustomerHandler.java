package server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import account.Account;

public class CustomerHandler extends Thread {
	
	private Socket client;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	private Account account;
	
	public CustomerHandler(Socket client, Account account) {
		this.client = client;
		this.account = account;
	}
	@Override
	public void run() {
		try {
			this.ois = new ObjectInputStream(client.getInputStream());
			this.oos = new ObjectOutputStream(client.getOutputStream());
			
			Integer customerID = (Integer) ois.readObject();
			int value;
			while((value = (Integer) ois.readObject()) != -99) {
				
				account.adjust(value);
			}
			oos.writeObject("Bank Acknowledges");
			System.out.printf("Client %d Transaction Complete\n",customerID);
			value = account.getBalance();
			account.adjust(-value);
			client.close();
			
		} catch(IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}		
	}
}
