/*******************************************************************************
* Name: Roland Williams
* Course: CIS 3970
* Semester: Spring 2024
* Assignment: LabW07
* Date started: 2/21/24
* Date finished: 2/29/24
* Description: Read the two database diagrams and create a project that instantiates multiple classes 
* including everyone that has something to do with a university and output their information
********************************************************************************/
package people;

public abstract class Person {
	protected String personID;
	protected String lastname;
	protected String firstname;
	protected boolean isEmployee;
	protected boolean isStudent;
	
		public Person(String personID,String lastname,String firstname, boolean isEmployee, boolean isStudent) {
		this.personID = personID;
		this.lastname = lastname;
		this.firstname = firstname;
		setIsEmployee(isEmployee);
		setIsStudent(isStudent);
	}
	public void setPersonID(String personID) {
		this.personID = personID;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public void setIsEmployee(boolean isEmployee) {
		if(isEmployee == true && isStudent != true) {
		this.isEmployee = isEmployee;
		}
		else {
			this.isEmployee = false;
		}
	}
	public void setIsStudent(boolean isStudent) {
		if(isStudent == true && isEmployee != true) {
		this.isStudent = isStudent;
		}
		else {
			this.isStudent = false;
		}
	}
	public String getPersonID() {
		return personID;
	}
	public String getLastname() {
		return lastname;
	}
	public String getFirstname() {
		return firstname;
	}
	public boolean getIsEmployee() {
		return isEmployee;
	}
	public boolean getIsStudent() {
		return isStudent;
	}
	@Override 
	public String toString() {
		return String.format("%s,%s,%s,%b,%b",personID,lastname,firstname,isEmployee,isStudent);
	}
}
