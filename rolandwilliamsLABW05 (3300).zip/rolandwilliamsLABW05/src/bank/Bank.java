package bank;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import security.Credential;
import stakeholders.Associate;
import stakeholders.Customer;
import stakeholders.Manager;
import stakeholders.Profile;

//class instantiates the ArrayLists of class Accounts, Customers, Managers,
	//+ and Associates and convert them from the binary files to the IDE output
	//and load each ArrayList and print them
public class Bank {

	private ArrayList<Account> Accounts;
	private ArrayList<Customer> Customers;
	private ArrayList<Manager> Managers;
	private ArrayList<Associate> Associates;
	private int cidGenerator;
	
	public Bank() {
		this.Accounts = new ArrayList<Account>();
		this.Customers = new ArrayList<Customer>();
		this.Managers = new ArrayList<Manager>();					//Bank constructor that instantiates the Account, Customer, Manager, and Associate ArrayList
		this.Associates = new ArrayList<Associate>();				//+setting the generator to 1,000,000
		this.cidGenerator = 1000000;
	}
	public ArrayList<Customer> loadCustomers(String fileName)throws IOException{		//throw IOException when dealing with data and file objects
		File file = new File(fileName);
		FileInputStream fistream = new FileInputStream(file);
		DataInputStream distream = new DataInputStream(fistream);			//instantiating the file into an fileinputstream and datainputstream to be able to read and print the file data
		while(distream.available()!= 0) {		
			int ID = distream.readInt();
			String firstName = distream.readUTF();
			String lastName = distream.readUTF();					//looping through customers.bin to read in the looped data in the format given and created customers and added them to the 
			String email = distream.readUTF();						//+ArrayList which is returned after all customers have been added		
			String username = distream.readUTF();
			String password = distream.readUTF();
			short pin = distream.readShort();
		
			Profile profile = new Profile(ID,firstName,lastName,email);
			Credential credential = new Credential(cidGenerator,username,password,pin);
			Customer customer = new Customer(profile,credential);
			Customers.add(customer);
			generateNextCID(); //iterating for every new customer created
		}
		distream.close();				
		return Customers;
	
	}
	public ArrayList<Manager> loadManagers(String fileName) throws IOException{
		File file = new File(fileName);
		FileInputStream fistream = new FileInputStream(file);
		DataInputStream distream = new DataInputStream(fistream);
		while(distream.available()!= 0) {		
			int ID = distream.readInt();
			String firstName = distream.readUTF();
			String lastName = distream.readUTF();
			String email = distream.readUTF();								//looping through managers.bin to read in the looped data in the format given and created managers and added them to the 
			String username = distream.readUTF();							//+ArrayList which is returned after all managers have been added
			String password = distream.readUTF();
			short pin = distream.readShort();
			int passcode = distream.readInt();
			String title = distream.readUTF();
			
			Profile profile = new Profile(ID,firstName,lastName,email);
			Credential credential = new Credential(cidGenerator,username,password,pin);
			Manager manager = new Manager(profile,credential,title,passcode);
			Managers.add(manager);
			generateNextCID();
	}
		distream.close();
		return Managers;
	
}
	public ArrayList<Associate> loadAssociates(String fileName) throws IOException{
		File file = new File(fileName);
		FileInputStream fistream = new FileInputStream(file);
		DataInputStream distream = new DataInputStream(fistream);
		while(distream.available()!= 0) {		
			int ID = distream.readInt();
			String firstName = distream.readUTF();
			String lastName = distream.readUTF();											//similiar to the methods above
			String email = distream.readUTF();
			String username = distream.readUTF();
			String password = distream.readUTF();
			short pin = distream.readShort();
			String title = distream.readUTF();
			
			Profile profile = new Profile(ID,firstName,lastName,email);
			Credential credential = new Credential(cidGenerator,username,password,pin);
			Associate associate = new Associate(profile,credential,title);
			Associates.add(associate);
			generateNextCID();
	}
		distream.close();
		return Associates;
	
}
	public ArrayList<Account> loadAccounts(String fileName)throws IOException{
		File file = new File(fileName);
		FileInputStream fistream = new FileInputStream(file);
		DataInputStream distream = new DataInputStream(fistream);
	
		while(distream.available()!= 0) {	
			int accountNum = distream.readInt();
			int managerID = distream.readInt();
			double balance = distream.readDouble();
			double APY = distream.readDouble();
			int numOwners = distream.readInt();
			ArrayList<Integer> Owners = new ArrayList<>();						//similar to methods above, except I created a loop given the amount of owners and displayed 
	
			int primaryID = distream.readInt(); 
            	Owners.add(0,primaryID);

            	for (int i = 1; i < numOwners; i++) {
            		Owners.add(distream.readInt());
            	}
            	Account account = new Account(accountNum,Owners,managerID,balance,APY,primaryID);
            	Accounts.add(account);
            	account.sort();
	
		}
		distream.close();
		return Accounts;
	
	}
	
	public int generateNextCID() {
		cidGenerator++;								//assumed method for iterating the Credentials 
		return cidGenerator;
	}
	
	@Override
	public String toString() {
		return String.format("%s\n\n%s\n\n%s\n\n%s\n\n", 
				Customers, Managers, Associates, Accounts);
	}
	
	public void banksort() {
		Collections.sort(Accounts);
		Collections.sort(Customers);
		Collections.sort(Managers);
		Collections.sort(Associates);
	}
	
	public ArrayList<Profile> profilecloning() throws CloneNotSupportedException{
		ArrayList<Profile> Profiles = new ArrayList<>();
		for(int i = 0; i < Customers.size();i++) {
			Profiles.add(Customers.get(i).getProfile().clone());
		}
		for(int i = 0; i < Managers.size();i++) {
			Profiles.add(Managers.get(i).getProfile().clone());
		}
		for(int i = 0; i < Associates.size();i++) {
			Profiles.add(Associates.get(i).getProfile().clone());
		}
		return Profiles;
	}
}

