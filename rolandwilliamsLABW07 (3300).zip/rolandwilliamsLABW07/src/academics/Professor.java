package academics;

import employee.Employee;
import facilities.Office;

public class Professor extends Employee{
	protected String professorRank;
	protected String professorSpecialty;
	public Professor(String personID,String lastname,String firstname, boolean isEmployee, boolean isStudent, String hireDate, String isAdmin, String isProf, Office office, String professorRank) {
		super(personID,lastname,firstname, true,false,hireDate,isAdmin,isProf,office);
		this.professorRank = professorRank;
	}
	public Professor(String employeeID,String lastname,String firstname, boolean isEmployee, boolean isStudent, String hireDate, String isAdmin, String isProf, Office office, String professorRank, String professorSpecialty) {
		super(employeeID,lastname,firstname, true,false,hireDate,"N","Y",office);
		this.professorSpecialty = professorSpecialty;
	}
	public void setProfessorRank(String professorRank) {
		this.professorRank = professorRank;
	}
	public void setProfessorSpecialty(String professorSpecialty) {
		this.professorSpecialty = professorSpecialty;
	}
	public String getProfessorRank() {
		return professorRank;
	}
	public String getProfessorSpecialty() {
		return professorSpecialty;
	}
	@Override
	public String toString() {
		if(professorRank != null) {
			return super.toString() + String.format(",%s", professorRank);
		}
		else {
			return super.toString() + String.format("%s,%s", professorSpecialty, professorRank);
		}
	}
}
