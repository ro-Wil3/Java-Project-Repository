package employee;

import people.Discrim;

public class Staff extends Employee implements Discrim{
	protected int staffLevel;
	protected String staffType;
	
	public Staff(String employeeID, String lastname,String firstname, String initial, String hireDate, String staff, String isAdmin, String isProf,int staffLevel, String staffType) {
		super(employeeID, lastname, firstname,initial, hireDate,"Y","N","N");
		this.staffLevel = staffLevel;
		setStaffType(staffType);
	}
	public void setStaffLevel(int staffLevel) {
		this.staffLevel = staffLevel;
	}
	public boolean setStaffType(String staffType) {
		if(staffType.equals(STF_IT)) {
			this.staffType = staffType;
			return true;
		}
		else {
			this.staffType = STF_ERROR;
			return false;
		}
	}
	public int getStaffLevel() {
		return staffLevel;
	}
	public String getStaffType() {
		return staffType;
	}
@Override
	public String toString() {
	return super.toString() + String.format(",%d,%s",staffLevel,staffType);
}
}
