package racing;

import java.util.ArrayList;

/*******************************************************************************
* Name: Roland Williams
* Course: (CIS 3970 Secure Programming Principles)
* Semester: (Spring 2024)
* Assignment: (Lab 13)
* Date started: (3/18/24)
* Date finished: (be honest – when did you finish this assignment)
* Description: (brief description based on the assignment instructions)
*******************************************************************************/
public class Track {
	
	public enum Flag {
		IDLE, GO
	};
	
	public static double length;
	public static Flag flag;
	public static ArrayList<Ship> winners;
	
	public Track(double length) {
		 Track.length = length;
		Track.flag = Flag.IDLE;
		winners = new ArrayList<>();
	}
	
	public void reset() {
		Track.flag = Flag.IDLE;
		winners.clear();
	}
}
