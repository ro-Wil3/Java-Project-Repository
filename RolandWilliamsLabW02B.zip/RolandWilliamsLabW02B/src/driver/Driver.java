package driver;

import java.util.Scanner;

import queens.Queens;

public class Driver {

	public static void main(String[] args) {
		Scanner scnr = new Scanner(System.in);		//input scanner
		System.out.print("Enter the board size: ");
		int bs = scnr.nextInt();					//board size user input
		Queens queens = new Queens(bs);
		if(queens.placeQueens(0)) {					//if all queens are placed, display them
			queens.display();
		}
		else {
			System.out.println("No solution");		//otherwise there is no solution
		}
		scnr.close();
	}

}
