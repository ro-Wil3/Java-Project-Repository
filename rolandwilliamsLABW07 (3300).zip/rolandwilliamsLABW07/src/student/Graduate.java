package student;

public class Graduate extends Student{
	protected String gradThesis;
	
	public Graduate(String personID,String lastname,String firstname, boolean isEmployee, boolean isStudent, String studentType,String studentMajor, int CWID, String gradThesis) {
		super(personID,lastname,firstname, false,true,"U",studentMajor,CWID);
		this.gradThesis = gradThesis;
	}
	public void setGradThesis(String gradThesis) {
		this.gradThesis = gradThesis;
	}
	public String getGradThesis() {
		return gradThesis;
	}
	@Override
	public String toString() {
		return super.toString() + String.format(",%s", gradThesis);
	}
}
