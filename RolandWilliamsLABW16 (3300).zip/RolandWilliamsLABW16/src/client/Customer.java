package client;

import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class Customer extends Thread{
		
	private Socket client;
	private String ip;
	private int port;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	private String filename;
	private Integer ID;
	
	public Customer(String ip, int port, String filename, Integer ID) {
		this.ip = ip;
		this.port = port;
		this.filename = filename;
		this.ID = ID;
	}

	@Override
	public void run() {
		try {
			File f = new File(filename);
			Scanner scnr = new Scanner(f);    
			this.client = new Socket(ip,port);
			this.oos = new ObjectOutputStream(client.getOutputStream());
			this.ois =  new ObjectInputStream(client.getInputStream());
			this.oos.writeObject(ID);
			
		    while(scnr.hasNext()) {
		    	Integer amount = scnr.nextInt();
		    	this.oos.writeObject(amount);
		    }
		    this.oos.writeObject(-99);
		    String acknowledge = (String) ois.readObject();
		    System.out.println(acknowledge);
		   
		    scnr.close();
		    client.close();
		} catch(IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}	
}
