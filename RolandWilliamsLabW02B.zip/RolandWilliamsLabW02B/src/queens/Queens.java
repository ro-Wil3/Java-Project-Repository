package queens;

import java.util.Arrays;

public class Queens {

	private final int SIZE;		//height and width of the board
	private int[][] board;		//2d array used to store "empty spaces " & "Queens"
	
	//Description: Constructor to initiate the size of the board
	public Queens(int size) {
		this.SIZE = size;
		this.board = new int[this.SIZE][this.SIZE];
	}
	//Description:  Displays the chess board
	//PreConditions: None
	//PostConditions: Uses a for loop to iterate through the entire array and display chess board
	public void display() {
		for(int i = 0; i < board.length; i++) {
			System.out.println(Arrays.toString(this.board[i]));
		}
	}
	//Description:  Places Queens on a chess board insuring that they aren't attacking each other
	//PreCondition: Ensure the row is within the bounds of the board to make sure the row-based approach is correct
	//PostCondition: All queens are placed on the chess board to where they can not attack each other
	public boolean placeQueens(int row) {
		if(row >= SIZE) {
			return true;		//base case
		}
		else {
			boolean queenPlaced = false;
			int col = 0;
			while(!queenPlaced && (col < SIZE)) {
				if(attackCheck(row, col)) {
					++col;
				}
				else {
					set(row,col);
					queenPlaced = placeQueens(row+1);
					if(!queenPlaced) {	//backtrack
						remove(row,col);
						++col;
					}
				}
			}
			return queenPlaced;
		}
	}
	
	//Description: Places Queen on Chess Board
	//PreCondition:  Row and column must be correct bounds on the board
	//PostConditions: The queen is placed on "row" & "column" of the board
	private void set(int row, int col) {
		board[row][col] = 1;
	}
	//Description: Removes Queen from Chess Board
	//PreCondition:  Row and column must be correct bounds on the board
	//PostConditions: The queen is removed from "row" & "column" of the board
	private void remove(int row, int col) {
		board[row][col] = 0;
	}
	/*private boolean attackCheck(int row, int col) {
		
		for (int i = 0; i < row; i++) {
            if (board[i][col] == 1) {
                return true;
            }
        }

        for (int i = row, j = col; i >= 0 && j >= 0; i--, j--) {
            if (board[i][j] == 1) {
                return true;
            }
        }

        for (int i = row, j = col; i < SIZE && j >= 0; i++, j--) {
            if (board[i][j] == 1) {
                return true;
            }
        }
		return false;
	}	*/
	private boolean attackCheck(int row, int col) {
	    // Check for a queen in the same column
	    for (int i = 0; i < row; i++) {
	        if (board[i][col] == 1) {
	            return true; 
	        }
	    }

	    // Check for a queen in the upper left diagonal
	    for (int i = row, j = col; i >= 0 && j >= 0; i--, j--) {
	        if (board[i][j] == 1) {
	            return true; 
	        }
	    }

	    // Check for a queen in the lower left diagonal
	    for (int i = row, j = col; i >= 0 && j < SIZE; i--, j++) {
	        if (board[i][j] == 1) {
	            return true; 
	        }
	    }

	    return false; 
	}
	
}
