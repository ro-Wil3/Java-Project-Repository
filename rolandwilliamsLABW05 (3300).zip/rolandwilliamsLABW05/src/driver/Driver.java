package driver;

import bank.Bank;

import stakeholders.Profile;
import java.io.*;
import java.util.ArrayList;
//class loads the ArrayLists and print them 
//(edit) It also sorts all of the ArrayList using the Collections class and print them
public class Driver {
	
	public static void main(String[] args) throws IOException, CloneNotSupportedException {
		Bank CISbank = new Bank();

		CISbank.loadCustomers("files/" + args[0]);
		CISbank.loadManagers("files/"+args[1]);
		CISbank.loadAssociates("files/"+args[2]);
		CISbank.loadAccounts("files/"+args[3]);
		System.out.println(CISbank);
		CISbank.banksort();
		ArrayList<Profile> profiles = CISbank.profilecloning();
	
		profiles.sort(null);
		System.out.println(profiles);
		System.out.println();
		System.out.println(CISbank);	
	}
}
