package driver;

import client.Customer;

public class Client {
	
	public static void main(String []args) {
		Customer client1 = new Customer("localhost", 9999, "files/transactions1.txt", 1);
		Customer client2 = new Customer("localhost", 9999, "files/transactions2.txt", 2);
		Customer client3 = new Customer("localhost", 9999, "files/transactions3.txt", 3);
		Customer client4 = new Customer("localhost", 9999, "files/transactions4.txt", 4);
		Customer client5 = new Customer("localhost", 9999, "files/transactions5.txt", 5);
		Customer client6 = new Customer("localhost", 9999, "files/transactions6.txt", 6);
		Customer client7 = new Customer("localhost", 9999, "files/transactions7.txt", 7);
		Customer client8 = new Customer("localhost", 9999, "files/transactions8.txt", 8);
		Customer client9 = new Customer("localhost", 9999, "files/transactions9.txt", 9);
		
		client1.start();
		client2.start();
		client3.start();
		client4.start();
		client5.start();
		client6.start();
		client7.start();
		client8.start();
		client9.start();
		
	}

}
