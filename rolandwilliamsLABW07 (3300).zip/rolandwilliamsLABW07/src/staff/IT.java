package staff;

import java.util.ArrayList;

import employee.Staff;
import training.Training;

public class IT extends Staff{
	private String itStaffGroup;
	protected ArrayList<Training> taken;
	
	public IT(String employeeID, String lastname,String firstname, String initial, String hireDate, String staff, String isAdmin, String isProf,int staffLevel, String staffType,String itStaffGroup,ArrayList<Training>taken) {
		super(employeeID, lastname, firstname,initial, hireDate,"Y","N","N",staffLevel,"IT");
		setITStaffGroup(itStaffGroup);
		this.taken = new ArrayList<Training>(taken);
	}
	
	public boolean setITStaffGroup(String itStaffGroup) {
		if(itStaffGroup.equals(IT_STAFF_AS)||itStaffGroup.equals(IT_STAFF_TS)) {
			this.itStaffGroup = itStaffGroup;
			return true;
		}
		else {
			this.itStaffGroup = IT_STAFF_ERROR;
			return false;
		}
	}
	
	public String getITStaffGroup() {
		return itStaffGroup;
	}
	
	@Override
	public String toString() {
		return super.toString() + String.format(",%s,%s",itStaffGroup,taken);
	}
}