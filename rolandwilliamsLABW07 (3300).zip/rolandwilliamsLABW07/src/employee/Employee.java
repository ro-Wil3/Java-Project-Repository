package employee;

import facilities.Office;
import people.Discrim;
import people.Person;

public class Employee extends Person implements Discrim{
	protected String hireDate;
	protected String isAdmin;
	protected String isProf;
	protected Office office;
	protected String employeeID;
	protected String initial;
	private String staff;
	
	public Employee(String personID,String lastname,String firstname, boolean isEmployee, boolean isStudent, String hireDate, String isAdmin, String isProf, Office office) {
		super(personID,lastname,firstname, true,false);
		this.hireDate = hireDate;
		setIsAdmin(isAdmin);
		setIsProf(isProf);
		this.office = office;
	}
	public Employee(String employeeID, String lastname,String firstname, String initial, String hireDate, String staff, String isAdmin, String isProf) { 
		super(employeeID, lastname, firstname, true, false);
		this.employeeID = employeeID;
		this.initial = initial;
		this.hireDate = hireDate;
		setStaff(staff);
		setIsAdmin(isAdmin);
		setIsProf(isProf);
	}
	public void setHireDate(String hireDate) {
		this.hireDate = hireDate;
	}
	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}
	public void setInitial(String initial) {
		this.initial = initial;
	}
	public boolean setStaff(String staff) {
		if(staff.equals(EMP_Y) || staff.equals(EMP_N)) {
			this.staff = staff;
			return true;
		}
		else {
			this.staff = EMP_ERROR;
			return false;
		}
	}
	public boolean setIsAdmin(String isAdmin) {
		if(isAdmin.equals(EMP_Y) || isAdmin.equals(EMP_N)) {
			this.isAdmin = isAdmin;
			return true;
		}
		else {
			this.isAdmin = EMP_ERROR;
			return false;
		}
	}
	public boolean setIsProf(String isProf) {
		if(isProf.equals(EMP_Y) || isProf.equals(EMP_N)) {
			this.isProf = isProf;
			return true;
		}
		else {
			this.isProf = EMP_ERROR;
			return false;
		}
	}
	public void setOffice(Office office) {
		this.office = office;
	}
	public String getHireDate() {
		return hireDate;
	}
	public String getEmployeeID() {
		return employeeID;
	}
	public String getInitial() {
		return initial;
	}
	public String getStaff() {
		return staff;
	}
	public String getIsAdmin() {
		return isAdmin;
	}
	public String getIsProf() {
		return isProf;
	}
	public Office getOffice() {
		return office;
	}
	@Override
	public String toString() {
		if(office != null){
		return super.toString() + String.format(",%s,%s,%s,%s",hireDate,isAdmin,isProf,office);
		}						//if statement testing to use personID or employeeID
		else {
			return String.format("%s,%s,%s,%s,%s,%s,%s,%s",employeeID,lastname,firstname,initial,hireDate,staff,isAdmin,isProf);
		}
	}
}
